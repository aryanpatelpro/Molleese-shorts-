# Step 8 of the skill, compact version: event table (timeline.py) -> synthesized SFX + original ragtime-march score, ducked under
# the voice (words.json), mixed to mix.wav (48 kHz stereo, exactly DUR). Standard mix: music +3 dB, SFX -6 dB, voice unchanged.
import json, numpy as np, soundfile as sf
from scipy import signal
import timeline as T
class Sig(np.ndarray):
    """ndarray whose + pads the shorter operand with silence (events of different lengths layer cleanly)"""
    def __add__(self, o):
        o = np.asarray(o); n = max(len(self), len(o)) if o.ndim else len(self)
        if not o.ndim: return np.add(np.asarray(self), o).view(Sig)
        a = np.pad(np.asarray(self), (0, n - len(self))); b = np.pad(o, (0, n - len(o))); return (a + b).view(Sig)
    __radd__ = __add__
SR = 48000; N = int(T.DUR * SR); rs = np.random.RandomState(7)
def env_exp(n, tau): return np.exp(-np.arange(n) / (tau * SR)).view(Sig)
def noise(n): return rs.randn(n).astype(np.float32).view(Sig)
def lp(x, f, o=2): return signal.sosfilt(signal.butter(o, f, "lp", fs=SR, output="sos"), x).astype(np.float32).view(Sig)
def hp(x, f, o=2): return signal.sosfilt(signal.butter(o, f, "hp", fs=SR, output="sos"), x).astype(np.float32).view(Sig)
def bp(x, a, b, o=2): return signal.sosfilt(signal.butter(o, [a, b], "bp", fs=SR, output="sos"), x).astype(np.float32).view(Sig)
def put(buf, t, x, g=1.0, pan=0.0):
    s = int(t * SR)
    if s >= N or s < 0: return
    x = x[: N - s]
    buf[0, s:s + len(x)] += x * g * (1 - max(0, pan)); buf[1, s:s + len(x)] += x * g * (1 + min(0, pan))
def tone(f, d, tau, harm=(1,), amp=(1,)):
    n = int(d * SR); t = np.arange(n) / SR
    return sum(a * np.sin(2 * np.pi * f * h * t) for h, a in zip(harm, amp)).astype(np.float32).view(Sig) * env_exp(n, tau)
def thump(f0, f1, d, tau):
    n = int(d * SR); t = np.arange(n) / SR; f = f1 + (f0 - f1) * np.exp(-t * 18)
    return (np.sin(2 * np.pi * np.cumsum(f) / SR) * env_exp(n, tau)).astype(np.float32).view(Sig)
def ping(f, d=0.5, tau=0.12): return tone(f, d, tau, (1, 2.76, 5.4), (1, 0.5, 0.25))

S = np.zeros((2, N), np.float32); M = np.zeros((2, N), np.float32)
# ---- SFX ----
def wave_roar():
    t = np.arange(N) / SR; env = np.array([T.wave_roar_envelope(x) for x in t[::480]]); env = np.interp(t, t[::480], env)
    n = lp(noise(N), 420, 3) * 2.2 + bp(noise(N), 80, 240) * 2.5
    S[0] += n * env * 0.9; S[1] += np.roll(n, 97) * env * 0.9
wave_roar()
for t0, d, a in T.whale_groans():                       # steel groans like a dying whale
    n = int(d * SR); tt = np.arange(n) / SR; f = 62 + 30 * np.sin(2 * np.pi * 0.6 * tt) - 10 * tt
    g = np.sin(2 * np.pi * np.cumsum(f) / SR + 2.2 * np.sin(2 * np.pi * 3.1 * tt)) * np.sin(np.pi * tt / d) ** 1.5
    put(S, t0, (g * a * 0.9).astype(np.float32)); put(S, t0, bp(noise(n), 300, 900) * np.sin(np.pi * tt / d) * 0.12 * a)
for tp in T.RIVET_POPS:                                  # rivets shoot off like machine-gun fire
    put(S, tp, bp(noise(1800), 1800, 5000) * env_exp(1800, 0.004) * 1.2 + ping(1250, 0.25, 0.07) * 0.5, 0.9, rs.uniform(-.3, .3))
for tb in T.BRUSH_SLAPS: put(S, tb, lp(noise(5000), 1400) * env_exp(5000, 0.035) * 1.6 + thump(220, 110, 0.12, 0.04) * 0.5, 0.8)
for (td, k) in T.syrup_drips(): put(S, td, ping(520 + 120 * (k % 3), 0.25, 0.05) * 0.35, 0.6, (k - 1) * 0.3)
put(S, T.FLASH - 0.05, lp(noise(24000), 3000) * np.sin(np.linspace(0, np.pi, 24000)) * 1.1 + thump(90, 38, 0.8, 0.25) * 1.2)  # hook flash
put(S, 25.9, thump(60, 45, 1.2, 0.4) * 0.4)               # pipe throb before pre-snap
for k in range(14): put(S, 22.0 + k * 0.30, thump(75, 50, 0.22, 0.07) * 0.25, 0.8)  # pump pulses (shot 6)
n = int(1.6 * SR)                                         # the snap
put(S, T.SNAP, bp(noise(n), 300, 6000) * env_exp(n, 0.25) * 1.8 + thump(80, 32, 1.6, 0.5) * 1.6 + ping(740, 1.2, 0.5) * 0.5)
n = int(2.4 * SR)                                         # slam into trestle + firehouse
put(S, T.DROP1 - 0.05, lp(noise(n), 1800) * env_exp(n, 0.55) * 2.2 + thump(70, 28, 2.4, 0.8) * 2.0 + bp(noise(n), 800, 4000) * env_exp(n, 0.2) * 0.8)
put(S, T.FREEZE0, lp(noise(int(1.4 * SR)), 500) * np.sin(np.linspace(0, np.pi, int(1.4 * SR))) * 0.7)   # glue sets
n = int(2.8 * SR)
put(S, T.HONEY_POUR_T0, bp(noise(n), 400, 1800) * (0.5 + 0.5 * np.sin(2 * np.pi * 13 * np.arange(n) / SR)) * np.sin(np.linspace(0, np.pi, n)) * 0.5)
put(S, T.SPOON_THUD, ping(2300, 0.9, 0.25) * 0.8 + ping(3900, 0.5, 0.1) * 0.3)
for h in T.SEAL_HITS: put(S, h, thump(160, 80, 0.3, 0.07) * 1.5 + bp(noise(2400), 1500, 6000) * env_exp(2400, 0.01) * 1.0)
for (ts, i, sp) in T.stroll_steps(): put(S, ts, lp(noise(1200), 900) * env_exp(1200, 0.012) * 0.22, 0.5, ((i % 7) - 3) * 0.1)
# ambience: harbor + street murmur under the town shots, wind in golden hour
n = N; amb = lp(noise(n), 700) * 0.035 + hp(lp(noise(n), 4000), 2000) * 0.006
S[0] += amb; S[1] += np.roll(amb, 211)
# ---- music: oom-pah ragtime march, original (C / F / G7), minor-tinged during the disaster, soft waltz-ish in golden hour ----
BPM = 112; spb = 60 / BPM
def midi(m): return 440 * 2 ** ((m - 69) / 12)
def pluck(f, d, vel):
    n = int(d * SR); t = np.arange(n) / SR
    return (sum(a * np.sin(2 * np.pi * f * h * t) for h, a in ((1, 1), (2, .5), (3, .28), (4, .12))) * np.exp(-t * 7.0) * vel).astype(np.float32)
CH = {"C": (48, [60, 64, 67]), "F": (53, [60, 65, 69]), "G7": (43, [59, 62, 65, 67]), "Am": (45, [60, 64, 69]), "Dm": (50, [62, 65, 69]), "E7": (40, [59, 62, 68])}
MEL = [72, 76, 79, 76, 72, 74, 76, 72, 71, 74, 77, 74, 72, 76, 79, 84]
b = 0; t = 0.3
prog = ["C", "C", "G7", "C", "F", "C", "G7", "C"]; dis = ["Am", "Am", "E7", "Am", "Dm", "Am", "E7", "E7"]
while t < T.DUR - 0.5:
    sect = 30.0 <= t < 41 and 1 or 0; gold = 41 <= t < 57
    p = (dis if sect else prog)[(b // 4) % 8]; root, tri = CH[p]
    vel = 0.5 if gold else 0.7 if sect else 0.6
    if b % 2 == 0: put(M, t, pluck(midi(root), spb * 0.9, vel), 0.9, -0.2)
    else:
        for m in tri: put(M, t, pluck(midi(m), spb * 0.5, vel * 0.45), 0.5, 0.2)
    if b % 4 in (0, 2) and not sect: put(M, t, pluck(midi(MEL[(b // 2) % 16]), spb * 1.8, 0.45), 0.7)
    if sect and b % 2 == 0: put(M, t, thump(70, 55, spb * 1.5, 0.3) * 0.5, 0.6)
    t += spb / (1 if gold else 1); b += 1
# ---- mix: duck music/ambience under voice, voice unchanged ----
v, _ = sf.read("voice.wav", dtype="float32"); v = v[:N]; v = np.pad(v, (0, N - len(v)))
words = json.load(open("words.json")); duck = np.ones(N, np.float32)
for w in words: duck[int(max(0, w["start"] - 0.08) * SR): int((w["end"] + 0.12) * SR)] = 0.28
duck = signal.sosfilt(signal.butter(1, 5, "lp", fs=SR, output="sos"), duck).astype(np.float32)
sfx = S * 10 ** (-6 / 20) * 0.55; mus = M * 0.16 * 10 ** (3 / 20) * duck
mix = np.stack([v, v]) * 0.9 + sfx + mus
mix = np.tanh(mix * 1.1) / 1.1
for k in range(int(0.08 * SR)): mix[:, k] *= k / (0.08 * SR); mix[:, N - 1 - k] *= k / (0.08 * SR)
sf.write("mix_raw.wav", mix.T, SR); sf.write("music_stem.wav", mus.T, SR); sf.write("sfx_stem.wav", sfx.T, SR)
print("mix_raw.wav", mix.shape[1] / SR, "s; peak", float(np.abs(mix).max()))

# ---- voice-free bed for the user's own voiceover: SFX + un-ducked music held ~-7 dB lower, -16 LUFS later ----
bed = S * 10 ** (-6 / 20) * 0.55 + M * 0.16 * 10 ** (3 / 20) * 0.45
bed = np.tanh(bed * 1.1) / 1.1
for k in range(int(0.08 * SR)): bed[:, k] *= k / (0.08 * SR); bed[:, N - 1 - k] *= k / (0.08 * SR)
sf.write("bed_raw.wav", bed.T, SR); print("bed_raw.wav ok")
