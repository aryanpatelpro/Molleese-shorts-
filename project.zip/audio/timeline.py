# Picture timeline mirrored from story.ts + cast.ts for "The Town That Drowned in Syrup" (Boston 1919)
# Drives the synthesized SFX + march/ragtime score in sfx_gen.py, music.py, and mix.py (48 kHz, -14 LUFS).
# Standard skill mix rules: music +3 dB, SFX -6 dB, voice unchanged.

import math
import numpy as np

FPS = 30
TOTAL = 1800
DUR = TOTAL / FPS            # 60.0 s exactly
fr = lambda f: f / FPS

SNAP = 30.20                 # Bottom rivet seam shears open (frame 906)
SURGE0 = 30.55               # Wave starts rushing down Commercial Street
DROP1 = 32.80                # Wave slams elevated train trestle & firehouse (frame 984)
FREEZE0 = 37.83              # Shot 10: winter air congeals syrup into glue
FLASH = fr(120)              # 4-frame white flash after the hook

# Rivet pop impulses before the rupture (Shot 7)
RIVET_POPS = [26.40, 27.15, 27.80, 28.45, 29.10, 29.65]

# Paint brush slaps on "slaps on brown paint" (Shot 5)
BRUSH_SLAPS = [18.40, 19.15, 19.90]

# Honey jar tilt & spoon clink in the golden-hour analogy (Shot 12)
HONEY_POUR_T0 = 45.20
SPOON_THUD = 48.35

# Engineer stamp hammer blows in Shot 14
SEAL_HITS = [55.40, 55.95, 56.50]
STROLL_T0 = 57.00

# id: (first frame, end frame, light, crowd)
SHOTS = {
    1:  (0,    120,  "day",    "wave"),
    2:  (120,  260,  "day",    "town"),
    3:  (260,  380,  "day",    "builders"),
    4:  (380,  510,  "day",    "kids"),
    5:  (510,  650,  "day",    "painter"),
    6:  (650,  775,  "day",    "pipe"),
    7:  (775,  900,  "day",    "panic"),
    8:  (900,  1050, "day",    "wave"),
    9:  (1050, 1135, "day",    "stuck"),
    10: (1135, 1225, "day",    "stuck"),
    11: (1225, 1335, "golden", "none"),
    12: (1335, 1500, "golden", "kitchen"),
    13: (1500, 1615, "golden", "wave"),
    14: (1615, 1710, "day",    "inspector"),
    15: (1710, TOTAL,"day",    "stroll"),
}
XFADE = {9: 6, 11: 8, 12: 8, 13: 8, 14: 8, 15: 8}


def shot_t(i):
    a, b = SHOTS[i][:2]
    return fr(a), fr(b)


def shot_at(t):
    f = t * FPS
    for i, (a, b, *_r) in SHOTS.items():
        if a <= f < b:
            return i
    return 15


def tau_of(shot, t):
    if shot == 1:
        return 31.0 + t
    if shot == 11:
        return t - 16.0
    if shot == 13:
        return t - 18.5
    return t


def _lin(pts, x):
    return float(np.interp(x, [p[0] for p in pts], [p[1] for p in pts]))


BULGE = [(0, 0), (12.6, 0.04), (17.0, 0.14), (21.6, 0.28), (25.8, 0.52), (SNAP, 0.85), (SNAP + 0.25, 0.0)]
WAVE_H = [(0, 0), (SURGE0, 0), (SURGE0 + 0.4, 7.6), (DROP1, 6.2), (35.0, 2.8), (FREEZE0, 1.15), (60.0, 1.15)]
VISC = [(0, 0.2), (21.6, 0.1), (35.0, 0.15), (FREEZE0, 0.92), (60.0, 1.0)]


def tank_bulge(tau):
    return _lin(BULGE, tau)


def wave_height(tau):
    return _lin(WAVE_H, tau)


def viscosity(tau):
    return _lin(VISC, tau)


def syrup_drips():
    """Shot 4: leaking syrup drops hitting the kids' wooden buckets (t, bucket_idx)"""
    a, b = shot_t(4)
    out = []
    t = a + 0.18
    k = 0
    while t < b - 0.1:
        out.append((t, k % 3))
        t += 0.34 + 0.08 * math.sin(k * 1.7)
        k += 1
    return out


def whale_groans():
    """Low-frequency metallic whale groans as the tank stretches in Shots 5, 7, and 11"""
    return [
        (17.20, 2.1, 0.75),  # Shot 5: "groans like a dying whale"
        (26.00, 2.8, 0.95),  # Shot 7: fermentation pressure spike
        (41.20, 2.4, 0.65),  # Shot 11: golden-hour pivot groan
    ]


def wave_roar_envelope(t):
    """Continuous low-end syrup tsunami roar envelope (0..1) for Shot 1, Shot 8-9, and Shot 13"""
    s = shot_at(t)
    tau = tau_of(s, t)
    if s not in (1, 8, 9, 13):
        return 0.0
    h = wave_height(tau)
    v = viscosity(tau)
    return float(np.clip((h / 7.6) * (1.0 - 0.7 * v), 0.0, 1.0))


def stroll_steps():
    """Shot 15: 16 citizens strolling along the rebuilt waterfront out of step"""
    a, b = shot_t(15)
    steps = []
    for i in range(16):
        sp = 0.6 + (i % 5) * 0.12
        ph0 = (i * 0.23) % 1.0
        k = 0
        while True:
            t = STROLL_T0 + (k * 0.5 - ph0) / sp
            k += 1
            if t < a:
                continue
            if t > b:
                break
            steps.append((t, i, sp))
    return sorted(steps, key=lambda x: x[0])