// Timeline of "The Town That Drowned in Syrup" (Great Molasses Flood, Boston 1919):
// 15 shots timed at 30 fps (1800 frames = 60.0 s), story physics (tank bulge, rivet pops, wave front, syrup viscosity)
// and reference camera grammar: continuous creeping push-ins (0.15-0.35 %/f, 0.6 %/f punch), symmetric smootherstep
// glides (18-40 f), hard cuts on big reframes, 7-frame sign-flipping impact kicks, and thin-lens DOF table.

export const FPS = 30;
export const TOTAL = 1800; // 60.0 s @ 30 fps
export const D0 = 2.0; // cobblestone street elevation above Boston Harbor water (m)
export const TANK_POS: V3 = [0, D0, 28]; // 50-ft (15.2 m) tall, 90-ft (27.4 m) diameter tank center
export const TANK_R = 13.7;
export const TANK_H = 15.2;
export const KITCHEN: V3 = [65, D0, -60]; // golden-hour analogy table position
export type V3 = [number, number, number];

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const smooth = (x: number) => { const u = clamp01(x); return u * u * (3 - 2 * u); };
export const easeOut = (u: number) => 1 - (1 - clamp01(u)) ** 4;
const lin = (pts: [number, number][], x: number) => {
  if (x <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) if (x <= pts[i][0]) {
    const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
    return y0 + ((y1 - y0) * (x - x0)) / (x1 - x0);
  }
  return pts[pts.length - 1][1];
};

// ---------------- story physics (tau = story time in seconds) ----------------
export const SNAP = 30.20;   // bottom rivet seam shears open (frame 906)
export const SURGE0 = 30.55; // wave begins rushing down Commercial Street
export const DROP1 = 32.80;  // wave slams into elevated train & firehouse (frame 984)
export const FREEZE0 = 37.83; // Shot 10: cold air turns syrup into waist-deep glue

/** Radial tank bulge (m) as fermentation pressure builds prior to SNAP */
export const tankBulge = (tau: number) =>
  lin([[0, 0], [12.6, 0.04], [17.0, 0.14], [21.6, 0.28], [25.8, 0.52], [SNAP, 0.85], [SNAP + 0.25, 0.0]], tau);

/** Leading edge Z position of the 35 mph (15.6 m/s) molasses wave rushing from z = +18 toward z = -45 */
export const waveFrontZ = (tau: number) =>
  lin([[0, TANK_POS[2] - TANK_R], [SURGE0, TANK_POS[2] - TANK_R], [DROP1, -14], [34.2, -26], [FREEZE0, -38], [60, -38]], tau);

/** Crest height (m) of the syrup wave (peaks at 7.6 m / 25 ft, settles to 1.1 m waist-deep muck) */
export const waveHeight = (tau: number) =>
  lin([[0, 0], [SURGE0, 0], [SURGE0 + 0.4, 7.6], [DROP1, 6.2], [34.0, 3.6], [35.0, 1.6], [FREEZE0, 1.15], [60.0, 1.15]], tau);

/** Viscosity index (0 = runny warm syrup, 1 = stiff winter quicksand) */
export const viscosityAt = (tau: number) =>
  lin([[0, 0.2], [21.6, 0.1], [35.0, 0.15], [FREEZE0, 0.92], [60.0, 1.0]], tau);

export type FloodState = {
  bulge: number;
  ruptured: boolean;
  peel: number;      // 0..1 steel wall peeling open
  waveZ: number;     // leading edge Z
  waveH: number;     // crest height (m)
  viscosity: number; // 0..1
};

// ---------------- shots ----------------
export type Light = "day" | "golden";
export type Crowd =
  | "wave"
  | "town"
  | "builders"
  | "kids"
  | "painter"
  | "pipe"
  | "panic"
  | "stuck"
  | "none"
  | "kitchen"
  | "inspector"
  | "stroll";

export type ShotDef = {
  id: number;
  a: number;
  b: number;
  light: Light;
  crowd: Crowd;
  tau: (t: number) => number;
  towns?: boolean;
};

export const SHOTS: ShotDef[] = [
  { id: 1,  a: 0,    b: 120,  light: "day",    crowd: "wave",      tau: (t) => 31.0 + t }, // Hook flash-forward
  { id: 2,  a: 120,  b: 260,  light: "day",    crowd: "town",      tau: (t) => t, towns: true },
  { id: 3,  a: 260,  b: 380,  light: "day",    crowd: "builders",  tau: (t) => t },
  { id: 4,  a: 380,  b: 510,  light: "day",    crowd: "kids",      tau: (t) => t },
  { id: 5,  a: 510,  b: 650,  light: "day",    crowd: "painter",   tau: (t) => t },
  { id: 6,  a: 650,  b: 775,  light: "day",    crowd: "pipe",      tau: (t) => t },
  { id: 7,  a: 775,  b: 900,  light: "day",    crowd: "panic",     tau: (t) => t },
  { id: 8,  a: 900,  b: 1050, light: "day",    crowd: "wave",      tau: (t) => t },
  { id: 9,  a: 1050, b: 1135, light: "day",    crowd: "stuck",     tau: (t) => t },
  { id: 10, a: 1135, b: 1225, light: "day",    crowd: "stuck",     tau: (t) => t },
  { id: 11, a: 1225, b: 1335, light: "golden", crowd: "none",      tau: (t) => t - 16.0 },
  { id: 12, a: 1335, b: 1500, light: "golden", crowd: "kitchen",   tau: (t) => t },
  { id: 13, a: 1500, b: 1615, light: "golden", crowd: "wave",      tau: (t) => t - 18.5 },
  { id: 14, a: 1615, b: 1710, light: "day",    crowd: "inspector", tau: (t) => t },
  { id: 15, a: 1710, b: TOTAL,light: "day",    crowd: "stroll",    tau: (t) => t, towns: true },
];

/** Crossfades (frames) at place/time changes; 4-frame white flash after the hook */
export const XFADE: Record<number, number> = { 9: 6, 11: 8, 12: 8, 13: 8, 14: 8, 15: 8 };
export const FLASH_AT = 120;

export const shotAt = (f: number) => SHOTS.find((s) => f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];

export const layersAt = (f: number): { id: number; alpha: number }[] => {
  for (const s of SHOTS) {
    const x = XFADE[s.id];
    if (x && f >= s.a - x / 2 && f < s.a + x / 2) {
      return [
        { id: s.id - 1, alpha: 1 },
        { id: s.id, alpha: (f - (s.a - x / 2) + 1) / (x + 1) },
      ];
    }
  }
  return [{ id: shotAt(f).id, alpha: 1 }];
};

export const floodState = (id: number, t: number): FloodState => {
  const s = SHOTS[id - 1];
  const tau = s.tau(t);
  if (id === 12 || id === 15) {
    return { bulge: 0, ruptured: false, peel: 0, waveZ: 14, waveH: 0, viscosity: 0 };
  }
  if (id === 9 || id === 10 || id === 14) {
    return {
      bulge: 0,
      ruptured: true,
      peel: 1,
      waveZ: waveFrontZ(tau),
      waveH: waveHeight(tau),
      viscosity: viscosityAt(tau),
    };
  }
  const ruptured = tau >= SNAP;
  if (id === 1) {
    // flash-forward: the wave creeps toward the driver standing at the look point (z = -6) so the shot stays readable
    return { bulge: 0, ruptured: true, peel: 1, waveZ: 8 - 2.2 * t, waveH: waveHeight(tau), viscosity: viscosityAt(tau) };
  }
  return {
    bulge: tankBulge(tau),
    ruptured,
    peel: ruptured ? easeOut((tau - SNAP) / 0.65) : 0,
    waveZ: waveFrontZ(tau),
    waveH: waveHeight(tau),
    viscosity: viscosityAt(tau),
  };
};

// ---------------- camera grammar ----------------
export type Cam = { pos: V3; look: V3; fov: number; roll: number };
type Shot = Partial<Cam> & { pos: V3; look: V3 };
type Key = { f: number; dur?: number; cut?: boolean; s: (f: number) => Shot };

export const glide = (u: number) => {
  const x = clamp01(u);
  return x * x * x * (x * (6 * x - 15) + 10);
};

const mix = (a: Cam, b: Cam, k: number): Cam => ({
  pos: a.pos.map((v, i) => v + (b.pos[i] - v) * k) as V3,
  look: a.look.map((v, i) => v + (b.look[i] - v) * k) as V3,
  fov: a.fov + (b.fov - a.fov) * k,
  roll: a.roll + (b.roll - a.roll) * k,
});

const full = (c: Shot): Cam => ({ fov: 40, roll: 0, ...c });

const run = (keys: Key[], f: number) => {
  let cur = full(keys[0].s(f));
  for (let i = 1; i < keys.length; i++) {
    const k = keys[i];
    if (f < k.f) break;
    cur = k.cut ? full(k.s(f)) : mix(cur, full(k.s(f)), glide((f - k.f) / (k.dur ?? 24)));
  }
  return cur;
};

const T = (f: number) => f / FPS;

const pushK = (f: number, f0: number, rate: number, punch = 0, n = 35) => {
  const x = Math.max(0, f - f0);
  let s = rate * x;
  if (punch > rate) {
    for (let i = 0; i < Math.min(x, n); i++) {
      s += (punch - rate) * Math.max(0, Math.min(1, (i + 0.5) / 8, (n - i - 0.5) / 8));
    }
  }
  return Math.exp(-s);
};

const dolly = (pos: V3, look: V3, k: number, rest: Partial<Cam> = {}): Shot => ({
  pos: [
    look[0] + (pos[0] - look[0]) * k,
    look[1] + (pos[1] - look[1]) * k,
    look[2] + (pos[2] - look[2]) * k,
  ],
  look,
  ...rest,
});

const zoom = (pos: V3, look: V3, fov: number, k: number, rest: Partial<Cam> = {}): Shot => ({
  pos,
  look,
  fov: (360 / Math.PI) * Math.atan(Math.tan((fov * Math.PI) / 360) * k),
  ...rest,
});

const rolled = (s: (f: number) => Shot, roll: number) => (f: number): Shot => ({ ...s(f), roll });

// ---- Shot framings (every hold creeps in; punch words get 0.006/f burst) ----
// Shot 1 (Hook): Low street view ahead of the 25-ft syrup wave -> close-up on the terrified wagon driver
const S1a = (f: number) => dolly([4.2, D0 + 2.1, -18], [0, D0 + 3.8, 2], pushK(f, 0, 0.0025), { fov: 44, roll: -0.04 });
const S1b = (f: number) => dolly([0.8, D0 + 1.6, -12], [0, D0 + 1.7, -6], pushK(f, 48, 0.003, 0.006, 32), { fov: 38, roll: 0.045 });

// Shot 2 (Setting aerial): Harbor & Commercial Street -> towering 50-ft steel tank
const S2a = (f: number) => zoom([22, 18, -32], [0, D0 + 7.5, 24], 44, pushK(f, 120, 0.002));
const S2b = (f: number) => zoom([11, 11, -12], [0, D0 + 7.0, 26], 40, pushK(f, 190, 0.002, 0.006, 35));

// Shot 3 (Builders): Shrugging blueprint foreman -> thin un-tested tank plates
const S3a = (f: number) => dolly([-2.8, D0 + 1.7, 9.5], [-1.2, D0 + 1.6, 14.2], pushK(f, 260, 0.0025), { fov: 38 });
const S3b = (f: number) => dolly([1.4, D0 + 1.5, 10.2], [0.4, D0 + 1.5, 14.0], pushK(f, 320, 0.002), { fov: 36, roll: -0.035 });

// Shot 4 (Leaking seams & kids with buckets): Seam close-up -> kids holding buckets for free syrup
const S4a = (f: number) => dolly([-1.8, D0 + 1.3, 11.2], [-0.5, D0 + 1.2, 14.3], pushK(f, 380, 0.0025), { fov: 36 });
const S4b = (f: number) => dolly([0.6, D0 + 1.1, 10.0], [0, D0 + 1.0, 13.8], pushK(f, 435, 0.002, 0.006, 30), { fov: 38, roll: 0.04 });

// Shot 5 (Groaning steel & brown paint cover-up): Manager in bowler hat slapping brown paint over leaking seam
const S5a = (f: number) => dolly([2.2, D0 + 1.7, 10.5], [0.8, D0 + 1.65, 14.2], pushK(f, 510, 0.0025), { fov: 38 });
const S5b = (f: number) => dolly([-0.4, D0 + 1.65, 10.8], [0.4, D0 + 1.6, 14.1], pushK(f, 575, 0.002, 0.006, 32), { fov: 35, roll: -0.04 });

// Shot 6 (Caribbean steamer): Harbor dock -> throbbing iron intake pipe
const S6a = (f: number) => dolly([14, D0 + 4.5, 4.0], [4, D0 + 2.5, 22], pushK(f, 650, 0.002), { fov: 42 });
const S6b = (f: number) => dolly([4.5, D0 + 1.8, 12.0], [1.8, D0 + 1.6, 15.5], pushK(f, 715, 0.003), { fov: 36 });

// Shot 7 (Fermentation & popping rivets): Bulging tank wall -> rivets shooting past watchman's hat
const S7a = (f: number) => zoom([-6.5, D0 + 3.2, 8.0], [0, D0 + 5.5, 16.0], 42, pushK(f, 775, 0.0025), { roll: -0.03 });
const S7b = (f: number) => dolly([-1.5, D0 + 1.75, 10.6], [-0.4, D0 + 1.7, 14.2], pushK(f, 835, 0.003, 0.006, 30), { fov: 35, roll: 0.045 });

// Shot 8 (The Snap & Tsunami): Bottom seam shear -> exploding steel -> aerial wave -> street-level slam
const S8a = (f: number) => dolly([-1.9, D0 + 1.2, 11.4], [-0.3, D0 + 1.1, 14.3], pushK(f, 900, 0.003, 0.006, 25), { fov: 34 });
const S8b = (f: number) => dolly([13.5, D0 + 4.0, 2.0], [0, D0 + 4.5, 15.0], pushK(f, 930, 0.0025), { fov: 44, roll: 0.05 });
const S8c = (f: number) => dolly([12.0, D0 + 14.0, -24.0], [0, D0 + 3.5, -4.0], pushK(f, 975, 0.0025), { fov: 44 });
const S8d = (f: number) => dolly([5.2, D0 + 2.2, -36.0], [0, D0 + 2.0, -24.0], pushK(f, 1010, 0.003), { fov: 42, roll: -0.045 });

// Shots 9 & 10 (Luckily / Unluckily): Shared camera gliding from fast wave to frozen waist-deep townsfolk
const S9a  = (f: number) => dolly([1.8, D0 + 2.1, -24.5], [0, D0 + 1.4, -18.0], pushK(f, 1050, 0.002), { fov: 40, roll: -0.03 });
const S10a = (f: number) => dolly([0.9, D0 + 1.75, -22.8], [0, D0 + 1.35, -18.2], pushK(f, 1135, 0.002, 0.006, 30), { fov: 36, roll: 0.04 });

// Shot 11 (Golden-hour pivot): Backlit silhouette of the tank & street
const S11a = (f: number) => zoom([15, D0 + 9.5, -28], [0, D0 + 5.5, 12], 40, pushK(f, 1225, 0.0018));

// Shot 12 (Golden-hour honey jar analogy): Warm runny honey vs cold stiff honey with standing spoon
const S12a = (f: number) => dolly([KITCHEN[0] + 0.4, D0 + 1.55, KITCHEN[2] - 6.5], [KITCHEN[0] + 0.4, D0 + 1.4, KITCHEN[2]], pushK(f, 1335, 0.0018), { fov: 38 });
const S12b = (f: number) => dolly([KITCHEN[0] - 1.1, D0 + 1.65, KITCHEN[2] - 5.2], [KITCHEN[0] + 0.2, D0 + 1.45, KITCHEN[2]], pushK(f, 1420, 0.002, 0.005, 30), { fov: 36, roll: 0.03 });

// Shot 13 (Golden-hour wave physics): Side tracking view of the wave slamming & congealing
const S13a = (f: number) => dolly([14.0, D0 + 2.8, -10.0], [0, D0 + 2.2, -6.0], pushK(f, 1500, 0.002), { fov: 42 });
const S13b = (f: number) => dolly([13.5, D0 + 1.8, -34.0], [0, D0 + 1.6, -24.0], pushK(f, 1560, 0.0025), { fov: 38, roll: -0.035 });

// Shot 14 (Consequence — Engineering seal law): Dazed cleanup crew -> Chief Engineer stamping the blueprint sign
const S14a = (f: number) => dolly([-3.8, D0 + 1.6, -25.0], [-2.0, D0 + 1.3, -18.5], pushK(f, 1615, 0.002), { fov: 40 });
const S14b = (f: number) => zoom([1.2, D0 + 1.6, -24.0], [2.6, D0 + 1.45, -18.5], 40, pushK(f, 1650, 0.0025, 0.005, 25));

// Shot 15 (Callback twist — Pancake scent on hot summer days): Strolling citizens sniffing sweet air -> Bezier crane pull-out
const S15a = (f: number) => dolly([1.6, D0 + 1.7, -14.0], [0, D0 + 1.55, -8.0], pushK(f, 1710, 0.0025), { fov: 40 });
const CRANE: V3[] = [[0, 15, -18], [18, 16, -38], [0, 6, 4]];
const S15b = (f: number): Shot => {
  const a = S15a(1748), s = glide((f - 1748) / 52), r = 1 - s, [C, B, L] = CRANE;
  return {
    pos: [0, 1, 2].map((i) => r * r * a.pos[i] + 2 * s * r * C[i] + s * s * B[i]) as V3,
    look: [0, 1, 2].map((i) => a.look[i] + (L[i] - a.look[i]) * s) as V3,
    fov: (a.fov ?? 40) + (44 - (a.fov ?? 40)) * s,
    roll: 0,
  };
};

const CAMS: Record<number, Key[]> = {
  1: [
    { f: 0, s: S1a },
    { f: 48, dur: 28, s: S1b },
  ],
  2: [
    { f: 120, s: S2a },
    { f: 190, dur: 24, s: S2b },
  ],
  3: [
    { f: 260, s: S3a },
    { f: 320, dur: 22, s: S3b },
  ],
  4: [
    { f: 380, s: S4a },
    { f: 435, dur: 24, s: S4b },
  ],
  5: [
    { f: 510, s: S5a },
    { f: 575, dur: 22, s: S5b },
    { f: 610, dur: 18, s: rolled(S5b, 0.035) },
  ],
  6: [
    { f: 650, s: S6a },
    { f: 715, cut: true, s: S6b },
  ],
  7: [
    { f: 775, s: S7a },
    { f: 835, cut: true, s: S7b },
  ],
  8: [
    { f: 900, s: S8a },
    { f: 918, cut: true, s: S8b },
    { f: 975, cut: true, s: S8c },
    { f: 1010, cut: true, s: S8d },
  ],
  9: [
    { f: 1050, s: S9a },
    { f: 1130, dur: 18, s: S10a }, // glides seamlessly across the 9 -> 10 cut
  ],
  11: [{ f: 1225, s: S11a }],
  12: [
    { f: 1335, s: S12a },
    { f: 1420, dur: 26, s: S12b },
  ],
  13: [
    { f: 1500, s: S13a },
    { f: 1560, cut: true, s: S13b },
  ],
  14: [
    { f: 1615, s: S14a },
    { f: 1650, cut: true, s: S14b },
  ],
  15: [
    { f: 1710, s: S15a },
    { f: 1748, cut: true, s: S15b },
  ],
};
CAMS[10] = CAMS[9];

// Impact kicks: image offset flips sign every frame (~3 px at 720p per unit) and decays over 7 frames
const KICKS: [number, number][] = [
  [27.80, 0.6], // rivet pop 1
  [28.45, 0.7], // rivet pop 2
  [SNAP,  1.4], // bottom seam shears open
  [DROP1, 1.8], // wave slams elevated train & firehouse
  [55.40, 0.6], // engineer seal stamp blow 1
  [55.95, 0.6], // engineer seal stamp blow 2
  [56.50, 0.8], // engineer seal stamp blow 3
];

export const kickAt = (t: number) => {
  let a = 0;
  for (const [t0, g] of KICKS) {
    const n = Math.floor((t - t0) * FPS + 1e-6);
    if (n >= 0 && n < 7) a += g * (n % 2 ? -1 : 1) * (1 - n / 7) ** 1.5;
  }
  return a;
};

export const camAt = (id: number, f: number): Cam => {
  const c = run(CAMS[id], f), a = kickAt(T(f));
  if (!a) return c;
  const d: V3 = [c.look[0] - c.pos[0], c.look[1] - c.pos[1], c.look[2] - c.pos[2]];
  const L = Math.hypot(...d), h = Math.hypot(d[0], d[2]) || 1;
  const m = (3 / 640) * Math.tan((c.fov * Math.PI) / 360) * L * a;
  return {
    ...c,
    look: [c.look[0] - (d[2] / h) * m, c.look[1] + 0.6 * m, c.look[2] + (d[0] / h) * m],
    roll: c.roll + a * 0.004,
  };
};

// ---------------- lens: depth of field + foreground framing ----------------
export type Dof = { f: number; dur?: number; cInf: number; focus?: (f: number) => V3 };
export const DOF: Dof[] = [
  { f: 0,    cInf: 14, focus: () => [0, D0 + 1.6, -6] },  // Hook driver close-up
  { f: 120,  cInf: 0 },                                   // Aerial town establishing (sharp)
  { f: 260,  cInf: 12, focus: () => [-1.2, D0 + 1.6, 14.2] }, // Builders MS
  { f: 380,  cInf: 14, focus: () => [0, D0 + 1.0, 13.8] },    // Kids with buckets CU
  { f: 510,  cInf: 12, focus: () => [0.4, D0 + 1.6, 14.1] },  // Painter MS
  { f: 650,  cInf: 0 },                                   // Harbor wide
  { f: 715,  cInf: 13 },                                  // Pipe insert
  { f: 775,  cInf: 0 },                                   // Bulging tank wide
  { f: 835,  cInf: 14 },                                  // Popping rivets CU
  { f: 900,  cInf: 14 },                                  // Seam shear insert
  { f: 918,  cInf: 0 },                                   // Wave burst & aerial (sharp)
  { f: 1050, cInf: 15, focus: () => [0, D0 + 1.4, -18.0] },   // Stuck in syrup MS/CU
  { f: 1225, cInf: 5 },                                   // Golden tank silhouette
  { f: 1335, cInf: 12, focus: () => [KITCHEN[0] + 0.2, D0 + 1.45, KITCHEN[2]] }, // Honey jars analogy
  { f: 1500, cInf: 0 },                                   // Golden wave tracking
  { f: 1615, cInf: 8 },                                   // Cleanup crew with foreground barrel
  { f: 1650, cInf: 12, focus: () => [2.6, D0 + 1.5, -18.5] }, // Engineer stamping blueprint
  { f: 1710, cInf: 0 },                                   // Waterfront stroll & crane out
];

export const dofAt = (f: number) => {
  let i = 0;
  while (i + 1 < DOF.length && f >= DOF[i + 1].f) i++;
  const d = DOF[i], p = DOF[Math.max(0, i - 1)];
  const k = d.dur ? Math.min(1, (f - d.f) / d.dur) : 1;
  return { cInf: p.cInf + (d.cInf - p.cInf) * k, focus: d.focus };
};

export type Fg = { a: number; b: number; kit: string; pos: V3; s?: number; yaw?: number };
export const FOREGROUND: Fg[] = [
  { a: 380,  b: 510,  kit: "cart",              pos: [-2.4, D0, 11.2], s: 0.85, yaw: 0.5 },
  { a: 1335, b: 1500, kit: "plant_bushDetailed", pos: [KITCHEN[0] - 0.8, D0, KITCHEN[2] - 3.6], s: 1.1, yaw: 0.3 },
  { a: 1615, b: 1650, kit: "cart",              pos: [-3.1, D0, -22.2], s: 0.85, yaw: 0.6 },
];