// 3D world for "The Town That Drowned in Syrup" (Boston 1919): North End cobblestone Commercial Street, brick rowhouses and
// the firehouse, the elevated railway trestle, Boston Harbor quay with the molasses steamer, the 50-ft riveted steel tank
// (deformed per frame by fermentation bulge and rivet-split peel), the 25-ft dynamic molasses wave, and the golden-hour
// honey-jar table. Sky / sun / fog / shadow rig, pooled lit billboards and the per-frame camera come from the skill's world.ts.
import * as THREE from "three";
import { getInputProps } from "remotion";
import { LIGHTS, LOOK, LightPreset } from "./lights";
import { TONE, CHAR, twoTone, untone } from "./shade";
import { NOINK } from "./ink";
import { Batch, V, lam, house, boxGeo } from "./build";
import { ctex, rep, cobbleHD, stoneHD, cloudHD } from "./paint";
import { Pool, Actor, Fx, stage } from "./cast";
import { FPS, D0, TANK_POS, TANK_R, TANK_H, KITCHEN, SHOTS, FOREGROUND, camAt, floodState, FloodState, ShotDef } from "./story";

// ---------------- 1919 molasses palette ----------------
export const PALETTE = {
  steelTank: "#5b626d",       // weathered riveted steel (lifted from #4a4d52 so the tank reads against the sky)
  freshBrownPaint: "#6a3f27", // slapdash brown paint over the leaks (shot 5)
  molassesWave: "#9a5521",    // glossy deep amber-brown syrup
  elevatedIron: "#3a4048",    // Boston Elevated Railway trestle
  cobbleStreet: "#8b8478",
  harborWater: "#3f78a8",
  brickRed: "#b0553a",
};

const steelTex = () => ctex("steelRivets", 1024, 512, (g, r) => {
  g.fillStyle = "#737a86"; g.fillRect(0, 0, 1024, 512);
  const PW = 128, PH = 128; // 8 x 4 plates
  for (let row = 0; row < 4; row++) for (let col = 0; col < 8; col++) {
    const v = 0.9 + 0.2 * r();
    g.fillStyle = `rgb(${Math.round(112 * v)},${Math.round(120 * v)},${Math.round(132 * v)})`;
    g.fillRect(col * PW, row * PH, PW, PH);
    // rust streaks
    g.fillStyle = "rgba(120,70,40,0.10)";
    for (let k = 0; k < 3; k++) g.fillRect(col * PW + r() * PW, row * PH, 5 + r() * 9, PH * (0.4 + 0.6 * r()));
  }
  g.strokeStyle = "rgba(25,24,32,0.9)"; g.lineWidth = 6;
  for (let i = 0; i <= 8; i++) { g.beginPath(); g.moveTo(i * PW, 0); g.lineTo(i * PW, 512); g.stroke(); }
  for (let j = 0; j <= 4; j++) { g.beginPath(); g.moveTo(0, j * PH); g.lineTo(1024, j * PH); g.stroke(); }
  g.fillStyle = "#2b2a33";
  for (let j = 0; j <= 4; j++) for (let i = 0; i < 8 * 7; i++) {
    const x = (i + 0.5) * (1024 / 56), y = j * PH;
    for (const dy of [-12, 12]) { g.beginPath(); g.arc(x, y + dy, 3.2, 0, 7); g.fill(); }
  }
});
const discTex = () => ctex("sunDisc", 128, 128, (g) => {
  const gr = g.createRadialGradient(64, 64, 58, 64, 64, 64); gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
});
const haloTex = () => ctex("sunHalo", 256, 256, (g) => {
  const im = g.createImageData(256, 256);
  for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
    const u = Math.hypot(x - 127.5, y - 127.5) / 128;
    const a = (0.55 * Math.exp(-((u / 0.25) ** 2)) + 0.35 * Math.exp(-((u / 0.6) ** 2))) * (1 - Math.min(1, Math.max(0, (u - 0.8) / 0.2)));
    const i = (y * 256 + x) * 4; im.data[i] = im.data[i + 1] = im.data[i + 2] = 255; im.data[i + 3] = Math.round(255 * Math.min(1, a));
  }
  g.putImageData(im, 0, 0);
});
const flat = (color: string, extra: THREE.MeshLambertMaterialParameters = {}) => twoTone(new THREE.MeshLambertMaterial({ color, ...extra }));

export class MolassesWorld {
  root = new THREE.Group();
  tankMesh: THREE.Mesh; paintPatchMesh: THREE.Mesh; waveMesh: THREE.Mesh; trestleColumn: THREE.Mesh; pipe: THREE.Mesh;
  private tankBasePos: Float32Array; private waveBasePos: Float32Array;
  private pool = new Pool(); private actors: Actor[] = []; private fxs: Fx[] = [];
  private hemi: THREE.HemisphereLight; private sun: THREE.DirectionalLight; private fill: THREE.DirectionalLight;
  private sky: THREE.Mesh; private skyMat: THREE.ShaderMaterial;
  private fog = new THREE.Fog("#bccbec", 25, 420);
  private sunDisc: THREE.Sprite; private sunHalo: THREE.Sprite;
  private sunCache = new Map<number, THREE.Vector3>();
  private cloudMaps: Record<"day" | "golden", THREE.Texture[]>; private clouds: THREE.Mesh[] = [];
  private fgs: { o: THREE.Object3D; a: number; b: number }[] = [];
  private frustum = new THREE.Frustum(); private m4 = new THREE.Matrix4(); private v = new THREE.Vector3(); private sph = new THREE.Sphere();

  constructor() {
    const R = this.root;
    // ---- sky + light rig (skill) ----
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: { c0: { value: new THREE.Color() }, c1: { value: new THREE.Color() }, c2: { value: new THREE.Color() }, c3: { value: new THREE.Color() }, c4: { value: new THREE.Color() }, e: { value: new THREE.Vector4() } },
      vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
      fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0));
          vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el));
          c = mix(c, c2, smoothstep(e.x, e.y, el));
          c = mix(c, c3, smoothstep(e.y, e.z, el));
          c = mix(c, c4, smoothstep(e.z, e.w, el));
          gl_FragColor = vec4(c, 1.0); }`,
      side: THREE.BackSide, depthWrite: false, fog: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1100, 48, 24), this.skyMat);
    this.sky.renderOrder = -1; this.sky.frustumCulled = false; this.sky.layers.set(NOINK); R.add(this.sky);
    this.sunDisc = new THREE.Sprite(new THREE.SpriteMaterial({ map: discTex(), color: new THREE.Color(6.0, 4.4, 2.4), fog: false, depthWrite: false }));
    this.sunHalo = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color: new THREE.Color(1, 1, 1), fog: false, depthWrite: false, depthTest: true, transparent: true, blending: THREE.AdditiveBlending }));
    this.sunDisc.renderOrder = -0.5; this.sunHalo.renderOrder = 5;
    for (const m of [this.sunDisc, this.sunHalo]) { m.frustumCulled = false; m.layers.set(NOINK); R.add(m); }
    this.hemi = new THREE.HemisphereLight("#cfe6ff", "#6c5c8c", 1.1);
    this.sun = new THREE.DirectionalLight("#fff0d6", 2.6);
    this.sun.castShadow = true; { const sm = (getInputProps() as { post?: { shadow?: number } }).post?.shadow ?? 2048; this.sun.shadow.mapSize.set(sm, sm); }
    this.fill = new THREE.DirectionalLight("#9fb8ff", 0.35);
    R.add(this.hemi, this.sun, this.sun.target, this.fill, this.fill.target);
    this.cloudMaps = { day: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.day.cloud)), golden: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.golden.cloud)) };
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + 0.3, d = 620 + (i % 3) * 60;
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: this.cloudMaps.day[i % 4], color: new THREE.Color(1.1, 1.1, 1.1), transparent: true, depthWrite: false, fog: false }));
      const w = 130 + (i % 4) * 30;
      m.position.set(Math.cos(a) * d, 120 + (i % 4) * 38, Math.sin(a) * d); m.scale.set(w, w / 2, 1); m.layers.set(NOINK);
      this.clouds.push(m); R.add(m);
    }

    // ---- ground, street, quay, harbour, rowhouses (static batch) ----
    const b = new Batch();
    const stone = flat("#8d867a"), cobble = lam("cobbleHD14", () => ({ map: rep(cobbleHD(), 14, 60), color: "#9a9aa6" })), quay = lam("quayStone", () => ({ map: stoneHD("copeHD") }));
    b.add(boxGeo(V(-900, D0 - 1.2, -900), V(-14, D0 - 0.02, 900), 0), stone);                    // west bank / sidewalk apron
    b.add(boxGeo(V(-14, D0 - 1.2, -900), V(14, D0 - 0.02, 900), 0), stone);                       // street bed under the cobble slab
    b.add(boxGeo(V(14, D0 - 1.2, -900), V(18, D0 - 0.02, 900), 0), stone);                        // quay apron
    b.add(boxGeo(V(18, -2, -900), V(19.4, D0, 900), 0), quay);                                    // quay wall down to the water
    // the user's cobbled Commercial Street slab (28 x 120)
    const street = new THREE.Mesh(new THREE.BoxGeometry(28, 0.04, 120), cobble);
    street.position.set(0, D0 - 0.01, 0); street.receiveShadow = true; R.add(street);
    // Boston Harbor
    const water = new THREE.Mesh(new THREE.PlaneGeometry(1800, 1800), flat(PALETTE.harborWater));
    water.rotation.x = -Math.PI / 2; water.position.set(19.4 + 900, 0.2, 0); water.receiveShadow = true; R.add(water);
    // brick rowhouses lining the west side (front faces +x); the firehouse (Engine 31) sits where the wave slams
    const HS = [8.4, 7, 9.8, 8.4, 7, 9.8, 8.4, 9.8, 7, 8.4];
    const SI = [7, 2, 7, 5, 2, 7, 6, 2, 7, 5];
    let zc = -62;
    for (let i = 0; i < HS.length; i++) {
      const w = 8.6 + (i % 3) * 0.6;
      if (i === 4) { house(b, -21.5, zc + 5, Math.PI / 2, 14, 11, 9.2, 2); zc += 14.4; continue; } // firehouse, wider
      house(b, -20, zc + w / 2, Math.PI / 2, w, 9, HS[i], SI[i]);
      zc += w + 0.4;
    }
    for (let i = 0; i < 4; i++) house(b, -20, 15 + i * 9.4, Math.PI / 2, 8.8, 9, HS[(i + 3) % HS.length], SI[(i + 1) % SI.length]);
    // far warehouse closing the street behind the tank
    house(b, 0, 66, Math.PI, 30, 10, 12, 7);
    // harbor-side warehouse blocks on the quay (north of the dock)
    for (let i = 0; i < 4; i++) house(b, 29, -56 + i * 11, -Math.PI / 2, 9, 10, 7 + (i % 2) * 1.4, 2 + ((i * 3) % 5));
    // elevated railway trestle: deck beam and columns (the hero column at z -14 snaps on DROP1)
    const iron = twoTone(new THREE.MeshPhongMaterial({ color: PALETTE.elevatedIron, specular: "#8a8a8a", shininess: 50 }), 0.15);
    const deck = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.9, 110), iron); deck.position.set(-5.5, D0 + 6.2, -10); deck.castShadow = true; R.add(deck);
    for (const rx of [-7.0, -4.0]) { const rail = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.18, 110), flat("#6f7680")); rail.position.set(rx, D0 + 6.75, -10); R.add(rail); }
    for (let z = -56; z <= 40; z += 12) {
      if (Math.abs(z + 14) < 7) continue;
      for (const x of [-7.2, -3.8]) { const c = new THREE.Mesh(new THREE.BoxGeometry(0.65, 6.2, 0.65), iron); c.position.set(x, D0 + 3.1, z); c.castShadow = true; R.add(c); }
    }
    const col2 = new THREE.Mesh(new THREE.BoxGeometry(0.65, 6.2, 0.65), iron); col2.position.set(-7.2, D0 + 3.1, -14); R.add(col2);
    this.trestleColumn = new THREE.Mesh(new THREE.BoxGeometry(0.65, 6.2, 0.65), iron);
    this.trestleColumn.position.set(-3.8, D0 + 3.1, -14.0); this.trestleColumn.castShadow = true; R.add(this.trestleColumn);
    // crates and barrels on the quay for set dressing
    const wood = flat("#8a5a36"), barrelM = flat("#a8703f");
    for (let i = 0; i < 9; i++) {
      const bx = 15.6 + (i % 2) * 0.9, bz = -38 + i * 5.3;
      const br = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.95, 14), barrelM); br.position.set(bx, D0 + 0.48, bz); br.castShadow = true; R.add(br);
    }
    for (let i = 0; i < 5; i++) { const cr = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.0, 1.1), wood); cr.position.set(16.2, D0 + 0.5, -30 + i * 9.5); cr.castShadow = true; R.add(cr); }
    b.build(R);

    // ---- the molasses steamer (shot 6): hull, house, funnel, and the iron intake pipe to the tank ----
    const hull = new THREE.Mesh(new THREE.BoxGeometry(11, 5.2, 46), flat("#2f3b52")); hull.position.set(26.5, 1.9, 22); hull.castShadow = true; R.add(hull);
    const hullRed = new THREE.Mesh(new THREE.BoxGeometry(11.05, 1.1, 46.05), flat("#a8423a")); hullRed.position.set(26.5, -0.1, 22); R.add(hullRed);
    const bridge = new THREE.Mesh(new THREE.BoxGeometry(7, 3.4, 9), flat("#e8e0cf")); bridge.position.set(26.5, 6.3, 34); bridge.castShadow = true; R.add(bridge);
    const funnel = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.4, 5.5, 18), flat("#1f2330")); funnel.position.set(26.5, 10.5, 28); funnel.castShadow = true; R.add(funnel);
    const band = new THREE.Mesh(new THREE.CylinderGeometry(1.14, 1.14, 0.9, 18), flat("#c93838")); band.position.set(26.5, 12.2, 28); R.add(band);
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.2, 11, 8), flat("#6b4a30")); mast.position.set(26.5, 9, 14); R.add(mast);
    // pipe: horizontal run from the ship's deck across the quay into the tank wall near the front
    const pipeMat = twoTone(new THREE.MeshPhongMaterial({ color: "#434a55", specular: "#9aa0ab", shininess: 55 }), 0.2);
    this.pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 24, 16), pipeMat);
    this.pipe.rotation.z = Math.PI / 2; this.pipe.position.set(15.2, D0 + 1.9, 14.3); this.pipe.castShadow = true; R.add(this.pipe);
    for (const px of [4.4, 8, 12, 16, 20]) { const fl = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.18, 16), pipeMat); fl.rotation.z = Math.PI / 2; fl.position.set(px, D0 + 1.9, 14.3); R.add(fl); }
    const stand = (x: number) => { const s = new THREE.Mesh(new THREE.BoxGeometry(0.4, 1.9, 0.4), pipeMat); s.position.set(x, D0 + 0.95, 14.3); R.add(s); };
    [6, 11, 16].forEach(stand);

    // ---- the 50-ft tank ----
    const tankGeo = new THREE.CylinderGeometry(TANK_R, TANK_R, TANK_H, 64, 24, false);
    this.tankBasePos = (tankGeo.attributes.position.array as Float32Array).slice();
    const tankMat = lam("steelTank", () => ({ map: rep(steelTex(), 6, 3.2), color: new THREE.Color(1.75, 1.7, 1.62) }));
    this.tankMesh = new THREE.Mesh(tankGeo, tankMat);
    this.tankMesh.position.set(TANK_POS[0], D0 + TANK_H / 2, TANK_POS[2]); this.tankMesh.castShadow = true; this.tankMesh.receiveShadow = true; R.add(this.tankMesh);
    const patchGeo = new THREE.CylinderGeometry(TANK_R + 0.03, TANK_R + 0.03, 4.2, 24, 1, true, Math.PI - 0.6, 1.2); // south (-z) face
    this.paintPatchMesh = new THREE.Mesh(patchGeo, flat(PALETTE.freshBrownPaint, { side: THREE.DoubleSide }));
    this.paintPatchMesh.position.set(TANK_POS[0], D0 + 2.4, TANK_POS[2]); R.add(this.paintPatchMesh);

    // ---- the wave ----
    const waveGeo = new THREE.BoxGeometry(22, 1, 45, 24, 8, 40);
    this.waveBasePos = (waveGeo.attributes.position.array as Float32Array).slice();
    const waveMat = twoTone(new THREE.MeshPhongMaterial({ color: PALETTE.molassesWave, specular: "#ffd08a", shininess: 30 }), 0.6);
    this.waveMesh = new THREE.Mesh(waveGeo, waveMat); this.waveMesh.castShadow = true; this.waveMesh.receiveShadow = true; R.add(this.waveMesh);

    // ---- golden-hour honey-jar table (shot 12) ----
    const [kx, , kz] = KITCHEN;
    const kp = new THREE.Mesh(new THREE.BoxGeometry(14, 0.1, 14), stone); kp.position.set(kx, D0 + 0.01, kz); kp.receiveShadow = true; R.add(kp);
    const kg = new THREE.Mesh(new THREE.BoxGeometry(9, 0.04, 9), lam("cobbleHD", () => ({ map: rep(cobbleHD(), 3, 3) }))); kg.position.set(kx, D0 + 0.06, kz); kg.receiveShadow = true; R.add(kg);
    const tableMat = flat("#9a6a3f");
    const top = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.1, 1.0), tableMat); top.position.set(kx, D0 + 0.92 - 0.05, kz); top.castShadow = true; top.receiveShadow = true; R.add(top);
    for (const [lx, lz] of [[-1.5, -0.42], [1.5, -0.42], [-1.5, 0.42], [1.5, 0.42]]) { const lg = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.87, 0.1), tableMat); lg.position.set(kx + lx, D0 + 0.43, kz + lz); lg.castShadow = true; R.add(lg); }
    const hb = new Batch();
    house(hb, kx - 9, kz + 4, Math.PI / 2 + 0.2, 8, 9, 8.4, 2); house(hb, kx + 9.5, kz + 3, -Math.PI / 2 - 0.1, 8, 9, 7, 7);
    house(hb, kx + 1, kz + 12, Math.PI, 12, 9, 9.8, 5);
    hb.build(R);

    // ---- foreground framing props (shots 4, 12, 14): a hand cart and a bush, drawn simply ----
    const cart = (x: number, y: number, z: number, s: number, yaw: number) => {
      const g = new THREE.Group(), w = flat("#9a6a3f"), d = flat("#5a3b24");
      const bed = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.35, 1.0), w); bed.position.y = 0.7; g.add(bed);
      for (const sx of [-1, 1]) { const side = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.45, 1.0), w); side.position.set(sx * 0.9, 1.05, 0); g.add(side); }
      for (const sz of [-1, 1]) { const wh = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.1, 18), d); wh.rotation.z = Math.PI / 2; wh.position.set(0, 0.45, sz * 0.58); g.add(wh); }
      const handle = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.08, 0.08), d); handle.position.set(1.5, 0.75, 0); g.add(handle);
      g.position.set(x, y, z); g.scale.setScalar(s); g.rotation.y = yaw; return g;
    };
    const bush = (x: number, y: number, z: number, s: number) => {
      const g = new THREE.Group(), l = flat("#5aa044");
      for (const [dx, dy, dz, r] of [[0, 0.6, 0, 0.7], [0.5, 0.45, 0.2, 0.5], [-0.45, 0.4, -0.1, 0.5]] as const) { const m = new THREE.Mesh(new THREE.SphereGeometry(r, 14, 10), l); m.position.set(dx, dy, dz); g.add(m); }
      g.position.set(x, y, z); g.scale.setScalar(s); return g;
    };
    for (const fg of FOREGROUND) {
      const o = fg.kit === "cart" ? cart(fg.pos[0], fg.pos[1], fg.pos[2], fg.s ?? 1, fg.yaw ?? 0) : bush(fg.pos[0], fg.pos[1], fg.pos[2], fg.s ?? 1);
      o.visible = false; R.add(o); this.fgs.push({ o, a: fg.a, b: fg.b });
    }
    // the hook's wagon behind the driver (shot 1 only; shown by update())
    this.hookWagon = cart(3.0, D0, -2.2, 1.15, 0.5); R.add(this.hookWagon);
  }
  private hookWagon: THREE.Object3D;

  private shotSun(id: number, s: ShotDef, L: LightPreset) {
    let v = this.sunCache.get(id);
    if (v) return v;
    let fx = 0, fz = 0;
    for (let f = s.a; f < s.b; f += 3) {
      const c = camAt(id, f), x = c.look[0] - c.pos[0], z = c.look[2] - c.pos[2], n = Math.hypot(x, z) || 1;
      fx += x / n; fz += z / n;
    }
    const n = Math.hypot(fx, fz) || 1; fx /= n; fz /= n;
    const az = THREE.MathUtils.degToRad(L.az), el = THREE.MathUtils.degToRad(L.el);
    const hx = fx * Math.cos(az) - fz * Math.sin(az), hz = fz * Math.cos(az) + fx * Math.sin(az);
    v = new THREE.Vector3(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize();
    this.sunCache.set(id, v);
    return v;
  }
  private actor(i: number) { while (this.actors.length <= i) this.actors.push(new Actor(this.root)); return this.actors[i]; }
  private fx(i: number) { while (this.fxs.length <= i) this.fxs.push(new Fx(this.root)); return this.fxs[i]; }

  /** Deforms tank barrel bulge and wall peel, updates the syrup wave, poses sky/light/camera and the cast for frame `f` */
  update(id: number, f: number, cam: THREE.PerspectiveCamera, scene: THREE.Scene): THREE.Vector3 {
    const t = f / FPS, s = SHOTS[id - 1], tau = s.tau(t), L = LIGHTS[s.light], K = LOOK[s.light];
    const fl: FloodState = floodState(id, t);

    // ---- camera ----
    const c = camAt(id, f);
    cam.position.set(...c.pos); cam.up.set(0, 1, 0); cam.lookAt(...c.look); cam.rotateZ(c.roll);
    cam.fov = c.fov; cam.near = 0.2; cam.far = 1500; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
    const focus = V(...c.look), dist = cam.position.distanceTo(focus);
    cam.layers.enable(NOINK);

    // ---- light rig: camera-relative sun frozen per shot, two-tone uniforms, shadow fit ----
    const sunDir = this.shotSun(id, s, L);
    this.hemi.color.set(L.sky); this.hemi.groundColor.set(L.ground); this.hemi.intensity = L.hemiI;
    this.sun.color.set(L.sunCol); this.sun.intensity = L.sunI;
    let Rr = THREE.MathUtils.clamp(dist * 1.15 + 7, 12, 95);
    if (id === 2 || id === 8 || id === 11 || id === 15) Rr = Math.max(Rr, 60);
    if (s.light === "golden") Rr = Math.max(Rr, 30);
    this.sun.position.copy(focus).addScaledVector(sunDir, 220); this.sun.target.position.copy(focus);
    const sc = this.sun.shadow.camera;
    sc.left = -Rr; sc.right = Rr; sc.top = Rr; sc.bottom = -Rr; sc.near = 20; sc.far = 480; sc.updateProjectionMatrix();
    this.sun.shadow.bias = L.bias; this.sun.shadow.normalBias = L.normalBias * (Rr / 12);
    this.fill.intensity = 0;
    TONE.uLitCol.value.set(...L.lit); TONE.uShadeCol.value.set(...L.shade); TONE.uShadeLift.value.set(...L.lift);
    TONE.uLambert.value = L.lambert; TONE.uSideK.value = L.sideK; TONE.uTerm.value = L.term; TONE.uBounce.value.set(...K.bounce); TONE.uSat.value = K.sat;
    CHAR.uCharTint.value.set(...L.charTint); CHAR.uCharShade.value = L.charShade; CHAR.uGrad.value = L.charGrad;
    CHAR.uBodyGrad.value = L.bodyGrad; CHAR.uSideTint.value.set(...L.sideTint);

    // ---- sky, fog, sun disc, clouds ----
    const su = this.skyMat.uniforms;
    K.sky.c.forEach((h, i) => untone(h, su["c" + i].value));
    const e = K.sky.e.map((deg) => THREE.MathUtils.degToRad(deg));
    su.e.value.set(e[1], e[2], e[3], e[4]);
    this.sky.position.copy(cam.position);
    untone(L.fog, this.fog.color); this.fog.near = L.fogNear; this.fog.far = L.fogFar;
    scene.fog = this.fog; scene.background = null;
    const showSun = s.light === "golden";
    this.sunDisc.visible = this.sunHalo.visible = showSun;
    if (showSun) {
      this.sunDisc.position.copy(cam.position).addScaledVector(sunDir, 900);
      this.sunDisc.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(1.7)));
      this.sunHalo.position.copy(this.sunDisc.position); this.sunHalo.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(24)));
      (this.sunHalo.material as THREE.SpriteMaterial).color.set(L.sunDisc).multiplyScalar(1.3);
    }
    for (let i = 0; i < this.clouds.length; i++) {
      const m = this.clouds[i], mat = m.material as THREE.MeshBasicMaterial;
      m.lookAt(cam.position.x, m.position.y, cam.position.z);
      mat.map = this.cloudMaps[s.light][i % 4];
    }
    for (const g of this.fgs) g.o.visible = f >= g.a && f < g.b && g.a < s.b && g.b > s.a;
    this.hookWagon.visible = id === 1;

    // ---- tank: radial barrel bulge + outward steel peel after SNAP (yours) ----
    const posAttr = this.tankMesh.geometry.attributes.position as THREE.BufferAttribute;
    const arr = posAttr.array as Float32Array;
    for (let i = 0; i < arr.length; i += 3) {
      const bx = this.tankBasePos[i], by = this.tankBasePos[i + 1], bz = this.tankBasePos[i + 2];
      const hNorm = (by + TANK_H / 2) / TANK_H;
      const barrel = Math.sin(Math.PI * Math.pow(hNorm, 0.75));
      const rScale = 1 + (fl.bulge * barrel) / TANK_R;
      const isSouthFace = bz < -TANK_R * 0.55;
      const peelOffset = isSouthFace ? fl.peel * 6.5 * (1 - hNorm * 0.5) : 0;
      arr[i] = bx * rScale + (bx >= 0 ? 1 : -1) * peelOffset;
      arr[i + 1] = by;
      arr[i + 2] = bz * rScale - peelOffset * 0.6;
    }
    posAttr.needsUpdate = true;
    this.tankMesh.geometry.computeVertexNormals();
    this.paintPatchMesh.visible = tau >= 17.0 && !fl.ruptured && id >= 5 && id <= 8;
    this.pipe.scale.setScalar(id === 6 ? 1 + 0.06 * Math.sin(t * 14) : 1); // throbbing intake pipe

    // ---- wave / quicksand bed (yours; front tall, tapering back, lobes when runny) ----
    this.waveMesh.visible = fl.waveH > 0.05;
    if (this.waveMesh.visible) {
      const wAttr = this.waveMesh.geometry.attributes.position as THREE.BufferAttribute;
      const wArr = wAttr.array as Float32Array;
      for (let i = 0; i < wArr.length; i += 3) {
        const wx = this.waveBasePos[i], wy = this.waveBasePos[i + 1], wz = this.waveBasePos[i + 2];
        const worldZ = fl.waveZ + wz + 22.5;
        const zn = (wz + 22.5) / 45; // 0 at the leading edge
        const taper = 0.55 + 0.45 * (1 - Math.min(1, zn * 1.6));
        const ripple = (1 - fl.viscosity * 0.85) * 0.45 * Math.sin(wx * 0.9 + t * 8.0) * Math.cos(worldZ * 0.6);
        const crestH = wy > 0 ? fl.waveH * taper + ripple : 0;
        wArr[i] = wx; wArr[i + 1] = wy > 0 ? Math.max(0.05, crestH) : 0; wArr[i + 2] = worldZ;
      }
      wAttr.needsUpdate = true;
      this.waveMesh.geometry.computeVertexNormals();
      this.waveMesh.geometry.computeBoundingSphere();
      this.waveMesh.position.set(0, D0, 0);
    }

    // ---- trestle column snaps when the wave hits (yours) ----
    if (tau >= 32.80 && id <= 8) {
      const u = Math.min(1, (tau - 32.80) / 0.5);
      this.trestleColumn.rotation.x = -0.65 * u; this.trestleColumn.position.y = D0 + 3.1 - 1.2 * u;
    } else if (id === 9 || id === 10 || id === 11 || id === 13 || id === 14 || id === 15) {
      const slammed = id !== 13 && id !== 11;
      this.trestleColumn.rotation.x = slammed ? -0.65 : 0; this.trestleColumn.position.y = D0 + 3.1 - (slammed ? 1.2 : 0);
      if (id === 13) { const u = tau >= 32.8 ? Math.min(1, (tau - 32.8) / 0.5) : 0; this.trestleColumn.rotation.x = -0.65 * u; this.trestleColumn.position.y = D0 + 3.1 - 1.2 * u; }
    } else { this.trestleColumn.rotation.x = 0; this.trestleColumn.position.y = D0 + 3.1; }

    // ---- cast + effects as lit billboards ----
    const right = V(0, 0, 0).setFromMatrixColumn(cam.matrixWorld, 0);
    const st = stage(id, t, fl, { pos: cam.position, right });
    this.frustum.setFromProjectionMatrix(this.m4.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
    const tint = s.light === "golden" ? "#ffcf9e" : "#ffffff";
    let ai = 0; const used: Actor[] = [];
    for (const p of st.places) {
      const sc2 = p.scale ?? 1;
      if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y + 1.1 * sc2, p.z), 3.5))) continue;
      const a = this.actor(ai++);
      const [w, h, k] = p.size ?? [300, 500, 0.5];
      a.r = this.pool.req(p.key, w, h, k, p.draw);
      a.mesh.visible = true; a.mesh.position.set(p.x, p.y, p.z);
      a.mesh.rotation.set(0, p.yaw ?? Math.atan2(cam.position.x - p.x, cam.position.z - p.z), p.roll ?? 0);
      a.mesh.scale.set(p.mirror ? -sc2 : sc2, sc2, sc2);
      if (a.mat.emissiveMap) a.mat.emissive.set(tint);
      a.mesh.castShadow = L.actorShadow;
      used.push(a);
    }
    for (let i = ai; i < this.actors.length; i++) this.actors[i].mesh.visible = false;
    let fi = 0; const fused: Fx[] = [];
    for (const p of st.fx) {
      if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y, p.z), Math.max(p.w, p.h)))) continue;
      const ex = this.fx(fi++);
      ex.r = this.pool.req(p.key, p.cw, p.ch, 1, p.draw);
      ex.use(!!p.soft); ex.mesh.visible = true; ex.mesh.position.set(p.x, p.y, p.z);
      if (p.flat) ex.mesh.rotation.set(-Math.PI / 2, 0, p.rot ?? 0);
      else { ex.mesh.quaternion.copy(cam.quaternion); ex.mesh.rotateZ(p.rot ?? 0); }
      ex.mesh.scale.set(p.w, p.h, 1);
      fused.push(ex);
    }
    for (let i = fi; i < this.fxs.length; i++) this.fxs[i].mesh.visible = false;
    this.pool.flush();
    for (const a of used) a.bind();
    for (const x of fused) x.bind();
    return focus;
  }
}
