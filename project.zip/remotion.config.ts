import { Config } from "@remotion/cli/config";
Config.setDelayRenderTimeoutInMilliseconds(240000);
